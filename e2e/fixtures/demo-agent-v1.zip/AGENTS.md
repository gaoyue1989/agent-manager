---
name: "E2E Demo Agent"
vendorKey: "e2e"
agentKey: "demo"
version: "1.0.0"
slug: "e2e/demo"
description: "E2E demo agent for platform release flow testing"
author: "@e2e"
license: "MIT"
tags: ["demo", "e2e"]
---

# E2E Demo

You are a minimal demo agent used by platform end-to-end tests.
