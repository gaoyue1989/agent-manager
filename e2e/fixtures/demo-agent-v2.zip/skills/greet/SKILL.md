---
name: greet
description: greet skill
---
# Greet
